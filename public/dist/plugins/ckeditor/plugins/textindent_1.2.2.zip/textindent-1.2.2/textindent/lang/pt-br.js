CKEDITOR.plugins.setLang( 'textindent', 'pt-br', {
    labelName: 'Inserir indentação da primeira linha'
});