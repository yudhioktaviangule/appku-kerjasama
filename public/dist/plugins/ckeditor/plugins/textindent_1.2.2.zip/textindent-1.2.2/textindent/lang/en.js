CKEDITOR.plugins.setLang( 'textindent', 'en', {
    labelName: 'Insert first line indentation'
});